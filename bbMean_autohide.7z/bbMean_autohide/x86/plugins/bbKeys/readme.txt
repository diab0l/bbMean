
    bbKeys 1.17
    ***********

      bbKeys is a plugin for Blackbox for Windows.
      Copyright � 2003-2009 grischka <grischka@users.sourceforge.net>

      http://bb4win.sourceforge.net/bblean
      http://bb4win.sourceforge.net/

      This program is free software, released under the GNU General
      Public License (GPL version 2). For details see:

            http://www.fsf.org/licenses/gpl.html

      THIS PROGRAM IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
      BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY
      OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.


    -----------------------------------------------------------------

    Further information can be found in the bblean documentation:
    See: docs/bblean.htm

